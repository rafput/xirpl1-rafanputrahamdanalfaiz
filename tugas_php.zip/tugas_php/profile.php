<?php 
    $nama= "Rafan Putra Hamdan Alfaiz";
    $umur= "16 tahun";
    $sekolah= "SMKN 2 BANDUNG";
    $citacita= "Pemain Manchester United";
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            display:flex;
            justify-content:center;
            margin:0;
            padding:0;
            align-items:center;
            height: 100vh;
            background-image: url('old-trafford-stadium.jpg');
        }
        h1 {
            font-size: 24px;
            color:white;
            margin-bottom: 20px;
        }
        .container {
            background: black;
            border-radius: 12px;
            box-shadow: 0 8px 16px rgba(0, 0, 0, 0.2);
            padding: 60px;
            max-width: 350px;
            text-align: center;
            transition: transform 0.3s, box-shaow 0.3s;
        }
        .container:hover {
            transform: scale(1.05);
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.3);
        }
        .edit {
            margin: 15px 0;
            font-size: 18px;
            color: white;
        }
        .edit span{
            font-weight: bold;
            color: white;
        }
        div a{
            text-decoration: none;
            color: white;
        }

    </style>
</head>
<body>
    <div class='container'>
        <h1>Informasi Diri</h1>
        <div class='edit'><?php echo "<span>Nama:</span> $nama"?></div>
        <div class='edit'><?php echo "<span>Umur:</span> $umur"?></div>
        <div class='edit'><?php echo "<span>Asal Sekolah:</span> $sekolah"?></div>
        <div class='edit'><?php echo "<span>Cita-Cita:</span> $citacita"?></div>
        <div><a href="index.php">Kembali</a></div>
    </div>
</body>
</html>